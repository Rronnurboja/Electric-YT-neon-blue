# Detailed Installation Guide

## Step-by-Step Instructions

### For Chrome, Brave, Edge, Opera:

1. **Download the Extension**
   - Click the green "Code" button above
   - Select "Download ZIP"
   - Extract the folder to your desktop

2. **Enable Developer Mode**
   - Open your browser
   - Go to `chrome://extensions/`
   - Toggle "Developer mode" ON (top-right corner)

3. **Load the Extension**
   - Click "Load unpacked" button
   - Select the extracted folder
   - The extension should now appear in your list

4. **Test it Out**
   - Go to [YouTube.com](https://www.youtube.com)
   - You should see the effects applied!

### For Firefox, Librewolf:

1. **Download the Extension**
   - Download this repository as ZIP
   - Extract to a folder

2. **Load Temporary Add-on**
   - Go to `about:debugging`
   - Click "This Firefox"
   - Click "Load Temporary Add-on"
   - Select the `manifest.json` file from the extracted folder

3. **Note**: Firefox requires reloading after browser restart

## 🎨 Customization
Edit the CSS files to customize colors:
- `yt-dark.css` - Dark theme styles
- `yt-light.css` - Light theme styles

## ❓ Troubleshooting
- **Extension not loading**: Make sure you extracted the ZIP file
- **No effect on YouTube**: Refresh YouTube page
- **Styles look broken**: Disable other YouTube extensions