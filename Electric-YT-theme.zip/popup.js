document.addEventListener('DOMContentLoaded', function() {
  const toggle = document.getElementById('toggleBtn');
  
  toggle.checked = true;
  
  toggle.addEventListener('change', function() {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: 'toggle',
        enabled: toggle.checked
      });
    });
    
    // Show message about refresh
    if (!toggle.checked) {
      alert('Effects disabled - page will refresh');
    } else {
      alert('Effects enabled - page will refresh');
    }
  });
});