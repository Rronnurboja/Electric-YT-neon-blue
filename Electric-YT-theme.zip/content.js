// Liquid Glass Theme - YouTube Only
console.log('🎯 Liquid Glass loaded on:', window.location.hostname);

// Main theme function
function applyLiquidGlassTheme() {
    // Only apply to YouTube (no early return)
    if (window.location.hostname.includes('youtube.com')) {
        console.log('🎯 Applying Liquid Glass to YouTube');
        
        // Force YouTube dark mode
        document.documentElement.setAttribute('dark', 'true');
        document.body.setAttribute('dark', 'true');
        document.body.setAttribute('data-host', 'youtube.com');
        
        const bodyStyle = window.getComputedStyle(document.body);
        const bgColor = bodyStyle.backgroundColor;
        console.log('Background color:', bgColor);

        const rgb = bgColor.match(/\d+/g);

        // Remove any previously loaded theme
        const existingTheme = document.getElementById('dynamic-theme');
        if (existingTheme) existingTheme.remove();

        const themeLink = document.createElement('link');
        themeLink.rel = 'stylesheet';
        themeLink.id = 'dynamic-theme';

        if (rgb && rgb.length >= 3) {
            const [r, g, b] = rgb.map(Number);
            const brightness = (r * 299 + g * 587 + b * 114) / 1000;
            
            console.log('Brightness detected:', brightness);
            
            // Use brightness ranges
            if (brightness >= 0 && brightness <= 80) {
                themeLink.href = chrome.runtime.getURL('yt-dark.css');
                console.log('🌙 Loading dark theme (brightness range: 0-80)');
            } else {
                themeLink.href = chrome.runtime.getURL('yt-light.css');
                console.log('🌞 Loading light theme (brightness range: 81-255)');
            }
        } else {
            // Fallback if can't detect brightness
            themeLink.href = chrome.runtime.getURL('yt-dark.css');
            console.log('🌙 Loading dark theme (fallback)');
        }
        
        document.head.appendChild(themeLink);
    }
    // If not YouTube, the function just ends peacefully
}

// Apply theme on load
setTimeout(applyLiquidGlassTheme, 1000);

// Watch for changes
const observer = new MutationObserver(applyLiquidGlassTheme);
observer.observe(document.body, { childList: true, subtree: true });