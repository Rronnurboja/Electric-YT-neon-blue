// Aggressive Brave to Electro replacement
const replaceBraveWithElectro = () => {
    // Try multiple selectors for the new tab page
    const braveTexts = [
        // Brave new tab page
        '#brave',
        '.brave',
        '[data-brave]',
        '*'
    ];
    
    braveTexts.forEach(selector => {
        try {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                if (element.children.length === 0) {
                    element.innerHTML = element.innerHTML.replace(/\bBrave\b/gi, 'Electro');
                }
            });
        } catch (e) {}
    });
    
    // Also try walking the DOM
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        {
            acceptNode: function(node) {
                if (node.parentElement && 
                    node.parentElement.tagName !== 'SCRIPT' && 
                    node.parentElement.tagName !== 'STYLE' &&
                    node.textContent.match(/\bBrave\b/gi)) {
                    return NodeFilter.FILTER_ACCEPT;
                }
                return NodeFilter.FILTER_SKIP;
            }
        },
        false
    );
    
    let node;
    while (node = walker.nextNode()) {
        node.textContent = node.textContent.replace(/\bBrave\b/gi, 'Electro');
    }
};

// Run repeatedly since new tab page loads dynamically
replaceBraveWithElectro();
setInterval(replaceBraveWithElectro, 1000);

const observer = new MutationObserver(replaceBraveWithElectro);
observer.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true
});